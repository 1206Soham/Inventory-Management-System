import pyodbc

# Connection string for ODBC DSN
conn_str = 'DSN=InventoryDB;UID=root;PWD=Soham@1206'

# Input validation
def get_valid_float(prompt):
    while True:
        try:
            value = float(input(prompt))
            if value >= 0:
                return value
            else:
                print("Please enter a positive number.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

def get_valid_int(prompt):
    while True:
        try:
            value = int(input(prompt))
            if value >= 0:
                return value
            else:
                print("Please enter a positive number.")
        except ValueError:
            print("Invalid input. Please enter a valid integer.")

"""Add a new product and its initial stock quantity to the database."""
def add_product(name, description, category, price, quantity):
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Insert product details into Products table
        product_query = """
            INSERT INTO Products (name, description, category, price)
            VALUES (?, ?, ?, ?)
        """
        cursor.execute(product_query, (name, description, category, price))
        conn.commit()

        # Get the product_id of the newly inserted product
        product_id = cursor.execute("SELECT LAST_INSERT_ID()").fetchone()[0]

        # Insert initial stock quantity into Inventory table
        inventory_query = """
            INSERT INTO Inventory (product_id, quantity)
            VALUES (?, ?)
        """
        cursor.execute(inventory_query, (product_id, quantity))
        conn.commit()

        print(f"Product '{name}' added successfully with Product ID: {product_id}")

    except pyodbc.Error as err:
        print(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

def update_stock(product_id, quantity_change):
    """Updates the stock quantity for a given product and logs the transaction."""
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Transaction type
        transaction_type = 'ADD' if quantity_change > 0 else 'REMOVE'

        # Update stock in Inventory table
        update_query = """
            UPDATE Inventory
            SET quantity = quantity + ?
            WHERE product_id = ?
        """
        cursor.execute(update_query, (quantity_change, product_id))
        conn.commit()

        # Insert transaction log into TransactionLog table
        log_query = """
            INSERT INTO TransactionLog (product_id, transaction_type, quantity_changed)
            VALUES (?, ?, ?)
        """
        cursor.execute(log_query, (product_id, transaction_type, abs(quantity_change)))
        conn.commit()

        print(f"Stock for Product ID {product_id} updated successfully and logged in transaction history.")

    except pyodbc.Error as err:
        print(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()


def view_products():
    """Displays all products with their details and stock quantities."""
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Retrieve product and inventory details
        query = """
            SELECT p.product_id, p.name, p.description, p.category, p.price, i.quantity
            FROM Products p
            JOIN Inventory i ON p.product_id = i.product_id
        """
        cursor.execute(query)

        # Fetch all rows and display
        rows = cursor.fetchall()
        print("\nProduct List:")
        print("ID | Name             | Category     | Price     | Quantity")
        print("---+------------------+--------------+-----------+---------")
        for row in rows:
            print(f"{row.product_id:<3}| {row.name:<17}| {row.category:<13}| {row.price:<10}| {row.quantity}")

    except pyodbc.Error as err:
        print(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

def search_product(name):
    """Searches for products by name."""
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Search for products matching the name
        query = """
            SELECT p.product_id, p.name, p.description, p.category, p.price, i.quantity
            FROM Products p
            JOIN Inventory i ON p.product_id = i.product_id
            WHERE p.name LIKE ?
        """
        cursor.execute(query, ('%' + name + '%',))

        # Fetch all matching rows
        rows = cursor.fetchall()
        if rows:
            print("\nSearch Results:")
            print("ID | Name             | Category     | Price     | Quantity")
            print("---+------------------+--------------+-----------+---------")
            for row in rows:
                print(f"{row.product_id:<3}| {row.name:<17}| {row.category:<13}| {row.price:<10}| {row.quantity}")
        else:
            print("No products found matching the search criteria.")

    except pyodbc.Error as err:
        print(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

def delete_product(product_id):
    """Deletes a product from the database."""
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Delete from Inventory table first due to foreign key constraint
        cursor.execute("DELETE FROM Inventory WHERE product_id = ?", (product_id,))
        conn.commit()

        # Delete from Products table
        cursor.execute("DELETE FROM Products WHERE product_id = ?", (product_id,))
        conn.commit()

        print(f"Product ID {product_id} deleted successfully.")

    except pyodbc.Error as err:
        print(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

def view_transaction_log(product_id):
    """Displays the transaction history for a specific product."""
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Retrieve transaction log for the given product
        query = """
            SELECT transaction_id, transaction_type, quantity_changed, timestamp
            FROM TransactionLog
            WHERE product_id = ?
            ORDER BY timestamp DESC
        """
        cursor.execute(query, (product_id,))

        # Fetch and display the results
        rows = cursor.fetchall()
        if rows:
            print(f"\nTransaction Log for Product ID {product_id}:")
            print("Transaction ID | Type  | Quantity | Timestamp")
            print("---------------+-------+----------+-------------------")
            for row in rows:
                print(f"{row.transaction_id:<14} | {row.transaction_type:<5} | {row.quantity_changed:<8} | {row.timestamp}")
        else:
            print(f"No transaction history found for Product ID {product_id}.")

    except pyodbc.Error as err:
        print(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

def update_price(product_id, new_price):
    """Updates the price of a product."""
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Update price in Products table
        update_query = """
            UPDATE Products
            SET price = ?
            WHERE product_id = ?
        """
        cursor.execute(update_query, (new_price, product_id))
        conn.commit()

        print(f"Price for Product ID {product_id} updated successfully to {new_price}.")

    except pyodbc.Error as err:
        print(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

def main():
    """Main function to interact with the Inventory Management System."""
    while True:
        print("\nInventory Management System")
        print("1. Add Product")
        print("2. Update Stock")
        print("3. View Products")
        print("4. Search Product")
        print("5. Delete Product")
        print("6. View Transaction Log")
        print("7. Update Price")
        print("8. Exit")

        choice = input("Enter your choice (1-8): ")

        if choice == '1':
            # Add Product
            name = input("Enter product name: ")
            description = input("Enter product description: ")
            category = input("Enter product category: ")
            price = float(input("Enter product price: "))
            quantity = int(input("Enter initial stock quantity: "))
            add_product(name, description, category, price, quantity)

        elif choice == '2':
            # Update Stock
            product_id = int(input("Enter product ID: "))
            quantity_change = int(input("Enter quantity to add/remove (use negative numbers to remove): "))
            update_stock(product_id, quantity_change)

        elif choice == '3':
            # View Products
            view_products()

        elif choice == '4':
            # Search Product
            search_term = input("Enter product name to search: ")
            search_product(search_term)

        elif choice == '5':
            # Delete Product
            product_id = int(input("Enter product ID to delete: "))
            delete_product(product_id)

        elif choice == '6':
            # View Transaction Log
            product_id = int(input("Enter product ID to view transaction log: "))
            view_transaction_log(product_id)

        elif choice == '7':
            # Update Price
            product_id = int(input("Enter product ID to update price: "))
            new_price = float(input("Enter new price: "))
            update_price(product_id, new_price)

        elif choice == '8':
            confirm_exit = input("Are you sure you want to exit? (y/n): ").lower()
            if confirm_exit == 'y':
                print("Exiting the Inventory Management System.")
                break
            else:
                continue 

        else:
            print("Invalid choice. Please enter a number between 1 and 8.")



if __name__ == "__main__":
    main()
