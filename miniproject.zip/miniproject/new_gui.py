import pyodbc
import tkinter as tk
from tkinter import messagebox, simpledialog
from tkinter import ttk

# Connection string for ODBC DSN
conn_str = 'DSN=InventoryDB;UID=root;PWD=Soham@1206'

# Function to display an error message in a messagebox
def show_error(message):
    messagebox.showerror("Error", message)

# Function to display an information message in a messagebox
def show_info(message):
    messagebox.showinfo("Info", message)

# Function to authenticate the user
def authenticate_user(root):
    password = simpledialog.askstring("Login", "Enter your password:", show='*', parent=root)
    # Replace "your_password" with your actual password
    return password == "SOHAM"

# Function to add a new product
def add_product_gui(name, description, category, price, quantity):
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Insert product details into Products table
        product_query = """
            INSERT INTO Products (name, description, category, price)
            VALUES (?, ?, ?, ?)
        """
        cursor.execute(product_query, (name, description, category, price))
        conn.commit()

        # Get the product_id of the newly inserted product
        product_id = cursor.execute("SELECT LAST_INSERT_ID()").fetchone()[0]

        # Insert initial stock quantity into Inventory table
        inventory_query = """
            INSERT INTO Inventory (product_id, quantity)
            VALUES (?, ?)
        """
        cursor.execute(inventory_query, (product_id, quantity))
        conn.commit()

        show_info(f"Product '{name}' added successfully with Product ID: {product_id}")

    except pyodbc.Error as err:
        show_error(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

# Function to update stock
def update_stock_gui(product_id, quantity_change):
    try:
        # Ensure quantity_change is an integer
        quantity_change = int(quantity_change)

        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Determine the transaction type
        transaction_type = 'ADD' if quantity_change > 0 else 'REMOVE'

        # Update stock in Inventory table
        update_query = """
            UPDATE Inventory
            SET quantity = quantity + ?
            WHERE product_id = ?
        """
        cursor.execute(update_query, (quantity_change, product_id))
        conn.commit()

        # Insert transaction log into TransactionLog table
        log_query = """
            INSERT INTO TransactionLog (product_id, transaction_type, quantity_changed)
            VALUES (?, ?, ?)
        """
        cursor.execute(log_query, (product_id, transaction_type, abs(quantity_change)))
        conn.commit()

        # Show success message
        show_info(f"Stock for Product ID {product_id} updated successfully.")

    except ValueError:
        # Handle case where quantity_change is not a valid integer
        show_error(f"Error: quantity_change must be a valid integer.")

    except pyodbc.Error as err:
        # Handle database errors
        show_error(f"Database Error: {err}")

    finally:
        # Ensure that the cursor and connection are properly closed
        try:
            if cursor:
                cursor.close()
        except pyodbc.Error:
            pass

        try:
            if conn:
                conn.close()
        except pyodbc.Error:
            pass


# Function to view all products
def view_products_gui():
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Retrieve product and inventory details
        query = """
            SELECT p.product_id, p.name, p.description, p.category, p.price, i.quantity
            FROM Products p
            JOIN Inventory i ON p.product_id = i.product_id
        """
        cursor.execute(query)

        for widget in product_list.winfo_children():
            widget.destroy()

        # Create the Treeview widget to display data as a table
        columns = ("product_id", "name", "description", "category", "price", "quantity")
        tree = ttk.Treeview(product_list, columns=columns, show="headings")

        # Define the headings for each column
        tree.heading("product_id", text="Product ID")
        tree.heading("name", text="Name")
        tree.heading("description", text="Description")
        tree.heading("category", text="Category")
        tree.heading("price", text="Price")
        tree.heading("quantity", text="Quantity")

        # Set column widths
        tree.column("product_id", width=80)
        tree.column("name", width=150)
        tree.column("description", width=200)
        tree.column("category", width=100)
        tree.column("price", width=80)
        tree.column("quantity", width=80)

        # Fetch rows from the database and insert into the Treeview
        rows = cursor.fetchall()
        for row in rows:
            tree.insert("", "end", values=(row.product_id, row.name, row.description, row.category, row.price, row.quantity))

        tree.pack(fill="both", expand=True)

    except pyodbc.Error as err:
        show_error(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

# Function to search for a product
def search_product_gui(name):
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        query = """
            SELECT p.product_id, p.name, p.description, p.category, p.price, i.quantity
            FROM Products p
            JOIN Inventory i ON p.product_id = i.product_id
            WHERE p.name LIKE ?
        """
        cursor.execute(query, ('%' + name + '%',))

        rows = cursor.fetchall()

        for widget in product_list.winfo_children():
            widget.destroy()

        if rows:
            columns = ("product_id", "name", "description", "category", "price", "quantity")
            tree = ttk.Treeview(product_list, columns=columns, show="headings")

            tree.heading("product_id", text="Product ID")
            tree.heading("name", text="Name")
            tree.heading("description", text="Description")
            tree.heading("category", text="Category")
            tree.heading("price", text="Price")
            tree.heading("quantity", text="Quantity")

            tree.column("product_id", width=80)
            tree.column("name", width=150)
            tree.column("description", width=200)
            tree.column("category", width=100)
            tree.column("price", width=80)
            tree.column("quantity", width=80)

            for row in rows:
                tree.insert("", "end", values=(row.product_id, row.name, row.description, row.category, row.price, row.quantity))

            tree.pack(fill="both", expand=True)

        else:
            show_info("No products found matching the search criteria.")

    except pyodbc.Error as err:
        show_error(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

# Function to delete a product
def delete_product_gui(product_id):
    try:
        conn = None  # Initialize conn to None
        # Ask for password confirmation
        password = simpledialog.askstring("Password Confirmation", "Enter your password to confirm:", show='*')
        
        if password != "BATMAN":  # Replace with your actual password or authentication method
            show_error("Incorrect password. Deletion canceled.")
            return

        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Delete from Inventory table first due to foreign key constraint
        cursor.execute("DELETE FROM Inventory WHERE product_id = ?", (product_id,))
        conn.commit()

        # Delete from Products table
        cursor.execute("DELETE FROM Products WHERE product_id = ?", (product_id,))
        conn.commit()

        show_info(f"Product ID {product_id} deleted successfully.")

    except pyodbc.Error as err:
        show_error(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

# Function to view transaction logs
def view_transaction_log_gui(product_id):
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        query = """
            SELECT transaction_id, transaction_type, quantity_changed, timestamp
            FROM TransactionLog
            WHERE product_id = ?
            ORDER BY timestamp DESC
        """
        cursor.execute(query, (product_id,))

        rows = cursor.fetchall()

        for widget in product_list.winfo_children():
            widget.destroy()

        if rows:
            columns = ("transaction_id", "transaction_type", "quantity_changed", "timestamp")
            tree = ttk.Treeview(product_list, columns=columns, show="headings")

            tree.heading("transaction_id", text="Transaction ID")
            tree.heading("transaction_type", text="Type")
            tree.heading("quantity_changed", text="Quantity Changed")
            tree.heading("timestamp", text="Timestamp")

            tree.column("transaction_id", width=120)
            tree.column("transaction_type", width=100)
            tree.column("quantity_changed", width=120)
            tree.column("timestamp", width=150)

            for row in rows:
                tree.insert("", "end", values=(row.transaction_id, row.transaction_type, row.quantity_changed, row.timestamp))

            tree.pack(fill="both", expand=True)

        else:
            show_info(f"No transaction history found for Product ID {product_id}.")

    except pyodbc.Error as err:
        show_error(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

# Function to update price of a product
def update_price_gui(product_id, new_price):
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Update price in Products table
        update_query = """
            UPDATE Products
            SET price = ?
            WHERE product_id = ?
        """
        cursor.execute(update_query, (new_price, product_id))
        conn.commit()

        show_info(f"Price for Product ID {product_id} updated successfully.")

    except pyodbc.Error as err:
        show_error(f"Error: {err}")

    finally:
        if conn:
            cursor.close()
            conn.close()

# Function to create the main GUI
def create_gui(root):
    global product_list

# Clear any existing widgets from the root window
    for widget in root.winfo_children():
        widget.destroy()

    # Create the main window
    root = tk.Tk()
    root.title("Inventory Management System")
    root.geometry("600x500")
    root.configure(bg="#ADD8E6")

    # Create buttons for each operation
    tk.Label(root, text="Inventory Management System", bg="#FFD580", font=("Arial", 25, "bold"), bd=2, relief="solid").pack(pady=20)

    # Add Product
    tk.Button(root, text="Add Product", width=20, bg="#90EE90", font=("Arial", 11), command=add_product_form).pack(pady=10)

    # Update Stock
    tk.Button(root, text="Update Stock", width=20, bg="#90EE90", font=("Arial", 11), command=update_stock_form).pack(pady=10)

    # Search Product
    tk.Button(root, text="Search Product", width=20, bg="#90EE90", font=("Arial", 11), command=search_product_form).pack(pady=10)

    # View Transaction Log
    tk.Button(root, text="View Transaction Log", width=20, bg="#90EE90", font=("Arial", 11), command=view_transaction_log_form).pack(pady=10)

    # Update Price
    tk.Button(root, text="Update Price", width=20, bg="#90EE90", font=("Arial", 11), command=update_price_form).pack(pady=10)

    # View Products
    tk.Button(root, text="View Products", width=20, bg="#F5F5DC", font=("Arial", 14, "bold"), command=view_products_gui).pack(pady=10)

    # Display Area for products and logs
    product_list = tk.Text(root, height=10, width=70)
    product_list.pack(pady=20)

    # Delete Product
    tk.Button(root, text="Delete Product", width=20, bg="#DC143C", fg="#F5F5DC", font=("Arial", 11), command=delete_product_form).pack(pady=10)

    # Exit
    tk.Button(root, text="Exit", width=20, bg="#F08080", font=("Arial", 13, "bold"), command=root.quit).pack(pady=10)

    # Start the GUI event loop
    root.mainloop()

# Function to create the login window and authenticate
def start_app():
    global root
    root = tk.Tk()
    root.withdraw()  # Hide the main window until authenticated

    if authenticate_user(root):
        root.deiconify()  # Show the main window if authenticated
        create_gui(root)
    else:
        show_error("Incorrect password. Access denied.")
        root.destroy()  # Close the application if authentication fails

# Forms for each operation
def add_product_form():
    create_form("Add Product", ["Name", "Description", "Category", "Price", "Quantity"], add_product_gui)

def update_stock_form():
    create_form("Update Stock", ["Product ID", "Quantity Change (+/-)"], update_stock_gui)

def search_product_form():
    create_form("Search Product", ["Product Name"], search_product_gui)

def delete_product_form():
    # Ask for confirmation first
    result = messagebox.askyesno("Confirmation", "Are you sure you want to delete a product?")
    if result:  # If the user clicks 'Yes'
        create_form("Delete Product", ["Product ID"], delete_product_gui)

def view_transaction_log_form():
    create_form("View Transaction Log", ["Product ID"], view_transaction_log_gui)

def update_price_form():
    create_form("Update Price", ["Product ID", "New Price"], update_price_gui)

# Helper function to create a form window for each operation
def create_form(title, fields, submit_action):
    form_win = tk.Toplevel()
    form_win.title(title)

    entries = []
    for idx, field in enumerate(fields):
        tk.Label(form_win, text=field).grid(row=idx, column=0, padx=10, pady=5)
        entry = tk.Entry(form_win)
        entry.grid(row=idx, column=1)
        entries.append(entry)

    def submit():
        values = [entry.get() for entry in entries]
        submit_action(*values)
        form_win.destroy()

    tk.Button(form_win, text="Submit", command=submit).grid(row=len(fields), column=1, pady=10)

# Run the program
start_app()
